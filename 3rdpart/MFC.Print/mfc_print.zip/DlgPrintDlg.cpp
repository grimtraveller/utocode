// DlgPrintDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DlgPrint.h"
#include "DlgPrintDlg.h"
#include "AboutDlg.h"

#include "PrintFrame.h"
#include "PrintView.h"

#include "math.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPrintDlg dialog

CDlgPrintDlg::CDlgPrintDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPrintDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgPrintDlg)
	m_bPrintHead = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDlgPrintDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPrintDlg)
	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Check(pDX, IDC_CHECK3, m_bPrintHead);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgPrintDlg, CDialog)
	//{{AFX_MSG_MAP(CDlgPrintDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_PRINT, OnPrint)
	ON_BN_CLICKED(IDC_PRINT_PREVIEW, OnPrintPreview)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	//}}AFX_MSG_MAP

	ON_MESSAGE(WM_BEGIN_PRINTING,OnBeginPrinting)
	ON_MESSAGE(WM_END_PRINTING,OnEndPrinting)
	ON_MESSAGE(WM_MY_PRINT,OnMyPrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPrintDlg message handlers

BOOL CDlgPrintDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_ListFont.CreatePointFont(100,"Times New Roman");

	DWORD dwExStyle = m_List.GetExStyle();
	dwExStyle&=~LVS_EX_CHECKBOXES;		
	
	m_List.SetFont(&m_ListFont);
	m_List.SetExtendedStyle(dwExStyle|LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT|LVS_EX_ONECLICKACTIVATE);

	m_List.InsertColumn(0,"ʱ��",LVCFMT_LEFT,70,-1);
	m_List.InsertColumn(1,"��ֵ1",LVCFMT_LEFT,70,-1);
	m_List.InsertColumn(2,"��ֵ2",LVCFMT_LEFT,70,-1);
	m_List.InsertColumn(3,"��ֵ3",LVCFMT_LEFT,70,-1);

	m_List.InsertColumn(4,"��ֵ4",LVCFMT_LEFT,80,-1);
	m_List.InsertColumn(5,"��ֵ5",LVCFMT_LEFT,80,-1);
	m_List.InsertColumn(6,"��ֵ6",LVCFMT_LEFT,80,-1);

	int i;
	for(i=0;i<51;i++)
	{
		CString str[7];
			
		str[0].Format("%.3f",(double)(i+1));
		str[1].Format("%.3f",1+sin(i));
		str[2].Format("%.3f",1+cos(i));
		str[3].Format("%.3f",1+sin(0.5*i));
		
		str[4].Format("%.3f",1+cos(0.5*i));
		str[5].Format("%.3f",1+sin(0.1*i));
		str[6].Format("%.3f",1+cos(0.1*i));
		m_List.InsertItem(i,str[0],-1);
		for(int j=1;j<=6;j++)
			m_List.SetItemText(i,j,str[j]);
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDlgPrintDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDlgPrintDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDlgPrintDlg::OnPrint() 
{
	CPrintFrame *pFrame = new CPrintFrame;
	pFrame->m_pCallerDlg = this;
	pFrame->Create(NULL,"Curve Print",WS_OVERLAPPEDWINDOW,CRect(0,0,0,0));
	pFrame->m_pView->OnMyPrint();
}

void CDlgPrintDlg::OnPrintPreview() 
{
	CPrintFrame *pFrame = new CPrintFrame;
	pFrame->m_pCallerDlg = this;
	pFrame->Create(NULL,"Curve Print Preview",WS_OVERLAPPEDWINDOW,CRect(0,0,0,0));
	pFrame->m_pView->OnMyPrintPreview();
}

void CDlgPrintDlg::OnAbout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}
void CDlgPrintDlg::PrintPageHeader(CDC* pDC, UINT nPageNumber, CPrintInfo* pInfo)
{
	CFont *pOldFont;
	CFont fontHeader;
	fontHeader.CreatePointFont(100,"FixedSys",pDC);
	pOldFont=(CFont *)(pDC->SelectObject(&fontHeader));
	int nPosY,nPosX;
	nPosY=3*m_cyPrinter;
	nPosX=m_cxOffset;
	pDC->TextOut(nPosX,nPosY,CString("�Ͼ����պ����ѧ"));
	CString str;
	str.Format("�� %d ҳ / �� %d ҳ",nPageNumber,pInfo->GetMaxPage());
	CSize size=pDC->GetTextExtent(str);
	nPosX=m_cxOffset+m_cxWidth-size.cx;
	pDC->TextOut(nPosX,nPosY,str);
	pDC->MoveTo(m_cxOffset,4*m_cyPrinter);
	pDC->LineTo(m_cxOffset+m_cxWidth,4*m_cyPrinter);
	pDC->SelectObject(pOldFont);
	fontHeader.DeleteObject();
}
LRESULT CDlgPrintDlg::OnBeginPrinting(WPARAM wParam,LPARAM lParam)
{

	CDC* pDC			= (CDC*)wParam;
	CPrintInfo* pInfo	= (CPrintInfo *)lParam;
	if(m_fontPrinter.m_hObject==NULL)
		m_fontPrinter.CreatePointFont(120,"FixedSys",pDC);
    TEXTMETRIC tm;
    CFont* pOldFont = pDC->SelectObject (&m_fontPrinter);
    pDC->GetTextMetrics (&tm);
    m_cyPrinter = tm.tmHeight + tm.tmExternalLeading;
    CSize size = pDC->GetTextExtent (_T ("---------1---------2---------" \
        "3---------4---------5---------6---------7---------8---"), 81);
    pDC->SelectObject (pOldFont);
    m_cxWidth = size.cx;

    m_nLinesPerPage = (pDC->GetDeviceCaps (VERTRES) -
        (m_cyPrinter * (3 + (2 * PRINTMARGIN)))) / m_cyPrinter;
	pInfo->SetMaxPage (2);

    m_cxOffset = (pDC->GetDeviceCaps (HORZRES) - size.cx) / 2;
	return TRUE;
}
LRESULT CDlgPrintDlg::OnEndPrinting(WPARAM wParam,LPARAM lParam)
{

	if(m_fontPrinter.m_hObject!=NULL)
		m_fontPrinter.DeleteObject ();
	return TRUE;
}
LRESULT CDlgPrintDlg::OnMyPrint(WPARAM wParam,LPARAM lParam)
{

	UINT gl_uNumOfPoints = 52;
	CDC* pDC			= (CDC*)wParam;
	CPrintInfo* pInfo	= (CPrintInfo *)lParam;
	int nPageNumber = pInfo->m_nCurPage;
	int i,j;
	CFont *pOldFont;
	CFont DataFont;
	DataFont.CreatePointFont(120,"����",pDC);
	if(nPageNumber==1)
	{
	
			TCHAR *pszTitle[7]={"Time","��ֵ1","��ֵ2","��ֵ3","��ֵ4","��ֵ5","��ֵ6"};
			pOldFont=pDC->SelectObject(&DataFont);
			pDC->Rectangle(m_cxOffset,(int)((2.5 + PRINTMARGIN)*m_cyPrinter),m_cxOffset+m_cxWidth,(m_nLinesPerPage+3 + PRINTMARGIN)*m_cyPrinter+20);
			for(i=1;i<7;i++)
			{
				pDC->MoveTo(m_cxOffset+i*m_cxWidth/7,(int)((2.5 + PRINTMARGIN)*m_cyPrinter));
				pDC->LineTo(m_cxOffset+i*m_cxWidth/7,(3 +m_nLinesPerPage+PRINTMARGIN)*m_cyPrinter+20);
			}
			pDC->MoveTo(m_cxOffset,(4 + PRINTMARGIN)*m_cyPrinter);
			pDC->LineTo(m_cxOffset+m_cxWidth,(4 + PRINTMARGIN)*m_cyPrinter);
			for(i=0;i<7;i++)
			{
				pDC->TextOut(m_cxOffset+50+i*m_cxWidth/7,(int)((2.8 + PRINTMARGIN)*m_cyPrinter),CString(pszTitle[i]));
			}
			for(i=0;i<(int)m_nLinesPerPage-1;i++)
			{
				CString str[7];
				int nIndex = (nPageNumber-1)*(m_nLinesPerPage-1)+i;
				if(nIndex<(int)gl_uNumOfPoints)
				{
					
					str[0].Format("%.3f",(double)(i+1));
					str[1].Format("%.3f",1+sin(i));
					str[2].Format("%.3f",1+cos(i));
					str[3].Format("%.3f",1+sin(0.5*i));
					
					str[4].Format("%.3f",1+cos(0.5*i));
					str[5].Format("%.3f",1+sin(0.1*i));
					str[6].Format("%.3f",1+cos(0.1*i));
					
					
					for(j=0;j<7;j++)
					{
						pDC->TextOut(m_cxOffset+50+j*m_cxWidth/7,(4 + PRINTMARGIN+i)*m_cyPrinter+5,str[j]);
					}
				}
			}
			pDC->SelectObject (pOldFont);
		
	}
	if(nPageNumber==2)
	{
		HBITMAP hBitmap=::LoadBitmap(AfxGetInstanceHandle(),(LPCTSTR)IDB_BITMAP1);
		BITMAP bitmap;
		::GetObject(hBitmap,sizeof(BITMAP),&bitmap);
		double dScale=(double)m_cxWidth/bitmap.bmWidth;
		int nScaledWidth=m_cxWidth;
		int nScaledHeight=(int)(bitmap.bmHeight*dScale);
		
		HDC dcMem;
		dcMem=::CreateCompatibleDC(pDC->m_hDC);
		HBITMAP hOldBmp=(HBITMAP)::SelectObject(dcMem,hBitmap);
		
		int nVertCenterPos = pDC->GetDeviceCaps (VERTRES) / 2;
		::StretchBlt(pDC->m_hDC,m_cxOffset,(4 + PRINTMARGIN)*m_cyPrinter,nScaledWidth,nScaledHeight,dcMem,0,0,bitmap.bmWidth,bitmap.bmHeight,SRCCOPY);
		
		
		::SelectObject(dcMem,hOldBmp);
		::DeleteDC(dcMem);
		::DeleteObject(hBitmap);
	}
	if(m_bPrintHead)
		PrintPageHeader(pDC,pInfo->m_nCurPage,  pInfo);
	return TRUE;
}
void CDlgPrintDlg::OnCheck3() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
}
