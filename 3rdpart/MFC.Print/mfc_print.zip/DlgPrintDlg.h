// DlgPrintDlg.h : header file
//

#if !defined(AFX_DLGPRINTDLG_H__FB717F8B_4016_4185_8F05_EACF7F1E83F8__INCLUDED_)
#define AFX_DLGPRINTDLG_H__FB717F8B_4016_4185_8F05_EACF7F1E83F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDlgPrintDlg dialog

class CDlgPrintDlg : public CDialog
{
// Construction
public:
	CDlgPrintDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgPrintDlg)
	enum { IDD = IDD_DLGPRINT_DIALOG };
	CListCtrl	m_List;
	BOOL	m_bPrintData;
	BOOL	m_bPrintImage;
	BOOL	m_bPrintHead;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgPrintDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:


	UINT m_cxWidth;
	UINT m_cxOffset;
	UINT m_nLinesPerPage;
	UINT m_cyPrinter;
	CFont		m_ListFont;
	CFont		m_fontPrinter;
public:
	void PrintPageHeader(CDC* pDC, UINT nPageNumber, CPrintInfo* pInfo);




protected:
	HICON m_hIcon;
	
	// Generated message map functions
	//{{AFX_MSG(CDlgPrintDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPrint();
	afx_msg void OnPrintPreview();
	afx_msg void OnAbout();
	afx_msg void OnCheck1();
	afx_msg void OnCheck2();
	afx_msg void OnCheck3();
	//}}AFX_MSG

	LRESULT OnBeginPrinting(WPARAM wParam,LPARAM lParam);
	LRESULT OnEndPrinting(WPARAM wParam,LPARAM lParam);
	LRESULT OnMyPrint(WPARAM wParam,LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPRINTDLG_H__FB717F8B_4016_4185_8F05_EACF7F1E83F8__INCLUDED_)
