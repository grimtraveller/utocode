//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//

// include the Resource IDs defined by Win32++
#include "Default_Resource.h"


//Resource IDs for menu items and Toolbar items
#define IDM_FILE_NEW                    101
#define IDM_FILE_OPEN                   102
#define IDM_FILE_SAVE                   103
#define IDM_FILE_SAVEAS                 104
#define IDM_FILE_PRINT                  105
#define IDM_FILE_CLOSE                  106
#define IDM_FILE_EXIT                   107
#define IDM_EDIT_UNDO                   110
#define IDM_EDIT_REDO                   111
#define IDM_EDIT_CUT                    112
#define IDM_EDIT_COPY                   113
#define IDM_EDIT_PASTE                  114
#define IDM_EDIT_DELETE                 115
#define IDM_HELP_ABOUT                  120


#define IDM_PEN_RED                     130
#define IDM_PEN_BLUE                    131
#define IDM_PEN_GREEN                   132
#define IDM_PEN_BLACK                   133

//Resource ID for the cursor
#define IDC_CURSOR1                     140

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           150
#endif
#endif





