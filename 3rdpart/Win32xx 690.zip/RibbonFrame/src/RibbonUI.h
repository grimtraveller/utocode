// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define cmdTabHome 10000  /* Tab Definitions */ 
#define cmdTabHome_LabelTitle_RESID 10001
#define cmdTabText 10010 
#define cmdTabText_LabelTitle_RESID 10011
#define cmdGroup1 11000  /* Group Definitions */ 
#define cmdGroup1_LabelTitle_RESID 11001
#define cmdGroup2 11010 
#define cmdGroup2_LabelTitle_RESID 11011
#define cmdGroup2_SmallImages_RESID 11012
#define cmdDropDownColorPickerGroup 11020 
#define cmdDropDownColorPickerGroup_LabelTitle_RESID 11021
#define cmdGroupRichFont 11030 
#define cmdGroupRichFont_LabelTitle_RESID 11031
#define IDC_CMD_NEW 12000  /* Button Definitions */ 
#define IDC_CMD_NEW_LabelTitle_RESID 12001
#define IDC_CMD_NEW_LargeImages_RESID 12002
#define IDC_CMD_OPEN 12010 
#define IDC_CMD_OPEN_LabelTitle_RESID 12011
#define IDC_CMD_OPEN_LargeImages_RESID 12012
#define IDC_CMD_SAVE 12020 
#define IDC_CMD_SAVE_LabelTitle_RESID 12021
#define IDC_CMD_SAVE_LargeImages_RESID 12022
#define IDC_CMD_SAVE_AS 12030 
#define IDC_CMD_SAVE_AS_LabelTitle_RESID 12031
#define IDC_CMD_SAVE_AS_LargeImages_RESID 12032
#define IDC_CMD_PRINT 12040 
#define IDC_CMD_PRINT_LabelTitle_RESID 12041
#define IDC_CMD_PRINT_LargeImages_RESID 12042
#define IDC_CMD_COPY 12050 
#define IDC_CMD_COPY_LabelTitle_RESID 12051
#define IDC_CMD_COPY_SmallImages_RESID 12052
#define IDC_CMD_CUT  12060 
#define IDC_CMD_CUT_LabelTitle_RESID 12061
#define IDC_CMD_CUT_SmallImages_RESID 12062
#define IDC_CMD_PASTE 12070 
#define IDC_CMD_PASTE_LabelTitle_RESID 12071
#define IDC_CMD_PASTE_LargeImages_RESID 12072
#define IDC_CMD_ABOUT 12080 
#define IDC_CMD_ABOUT_LabelTitle_RESID 12081
#define IDC_CMD_ABOUT_LargeImages_RESID 12082
#define IDC_CMD_EXIT 12090 
#define IDC_CMD_EXIT_LabelTitle_RESID 12091
#define IDC_CMD_EXIT_LargeImages_RESID 12092
#define IDC_PEN_COLOR 13000  /* DropDownColorPicker ThemeColors */ 
#define IDC_PEN_COLOR_LabelTitle_RESID 60001
#define IDC_PEN_COLOR_LabelDescription_RESID 60002
#define IDC_PEN_COLOR_LargeImages_RESID 13001
#define IDC_RICHFONT 14000  /* Font Picker */ 
#define IDC_RICHFONT_Keytip_RESID 60003
#define IDC_MRUMENU 14010 
#define IDC_MRULIST 14020 
#define IDC_QAT 14030 
#define IDC_CUSTOMIZE_QAT 14040 
#define IDC_RIBBONHELP 14050 
