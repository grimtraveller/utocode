; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CImgTestDlg
LastTemplate=generic CWnd
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ImgTest.h"

ClassCount=3
Class1=CImgTestApp
Class2=CImgTestDlg

ResourceCount=4
Resource2=IDD_IMGTEST_DIALOG
Resource1=IDR_MAINFRAME
Class3=CWndImage
Resource3=IDD_IMGTEST_DIALOG (English (U.S.))
Resource4=IDD_ABOUT (English (U.S.))

[CLS:CImgTestApp]
Type=0
HeaderFile=ImgTest.h
ImplementationFile=ImgTest.cpp
Filter=N

[CLS:CImgTestDlg]
Type=0
HeaderFile=ImgTestDlg.h
ImplementationFile=ImgTestDlg.cpp
Filter=D
LastObject=CImgTestDlg
BaseClass=CDialog
VirtualFilter=dWC



[DLG:IDD_IMGTEST_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CImgTestDlg

[DLG:IDD_IMGTEST_DIALOG (English (U.S.))]
Type=1
Class=CImgTestDlg
ControlCount=15
Control1=IDC_1_1,button,1342308361
Control2=IDC_STRETCH,button,1342177289
Control3=IDC_STRETCHXY,button,1342177289
Control4=IDC_STRETCHSM,button,1342177289
Control5=IDC_TILE,button,1342177289
Control6=IDC_RB_LEFT,button,1342312457
Control7=IDC_CENTERX,button,1342181385
Control8=IDC_RIGHT,button,1342181385
Control9=IDC_TOP,button,1342312457
Control10=IDC_CENTERY,button,1342181385
Control11=IDC_BOTTOM,button,1342181385
Control12=IDC_CB_CUSTOM,button,1342246915
Control13=IDC_INFO,button,1342242816
Control14=IDC_CB_WINBACK,button,1342242819
Control15=IDC_ST_IMG,static,1350696961

[CLS:CWndImage]
Type=0
HeaderFile=WndImage.h
ImplementationFile=WndImage.cpp
BaseClass=CWnd
Filter=W
VirtualFilter=WC

[DLG:IDD_ABOUT (English (U.S.))]
Type=1
Class=?
ControlCount=5
Control1=IDOK,button,1342242817
Control2=IDC_STATIC,static,1342308353
Control3=IDC_STATIC,static,1342308353
Control4=IDC_STATIC,static,1342308353
Control5=IDC_STATIC,static,1342308353

