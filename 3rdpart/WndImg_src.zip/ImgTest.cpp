// ImgTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ImgTest.h"
#include "ImgTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImgTestApp

BEGIN_MESSAGE_MAP(CImgTestApp, CWinApp)
	//{{AFX_MSG_MAP(CImgTestApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImgTestApp construction

CImgTestApp::CImgTestApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CImgTestApp object

CImgTestApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CImgTestApp initialization

BOOL CImgTestApp::InitInstance()
{
	// Standard initialization

	CImgTestDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
