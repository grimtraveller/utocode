// ImgTest.h : main header file for the IMGTEST application
//

#if !defined(AFX_IMGTEST_H__F782C14A_E810_43A1_9423_48E71080F7FB__INCLUDED_)
#define AFX_IMGTEST_H__F782C14A_E810_43A1_9423_48E71080F7FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CImgTestApp:
// See ImgTest.cpp for the implementation of this class
//

class CImgTestApp : public CWinApp
{
public:
	CImgTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImgTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CImgTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMGTEST_H__F782C14A_E810_43A1_9423_48E71080F7FB__INCLUDED_)
