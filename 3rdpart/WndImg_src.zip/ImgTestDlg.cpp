// ImgTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ImgTest.h"
#include "ImgTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImgTestDlg dialog

CImgTestDlg::CImgTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CImgTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CImgTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CImgTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImgTestDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CImgTestDlg, CDialog)
	//{{AFX_MSG_MAP(CImgTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_1_1, On11)
	ON_BN_CLICKED(IDC_STRETCH, OnStretch)
	ON_BN_CLICKED(IDC_STRETCHXY, OnStretchxy)
	ON_BN_CLICKED(IDC_STRETCHSM, OnStretchsm)
	ON_BN_CLICKED(IDC_TILE, OnTile)
	ON_BN_CLICKED(IDC_RB_LEFT, OnRbLeft)
	ON_BN_CLICKED(IDC_CENTERX, OnCenterx)
	ON_BN_CLICKED(IDC_RIGHT, OnRight)
	ON_BN_CLICKED(IDC_TOP, OnTop)
	ON_BN_CLICKED(IDC_CENTERY, OnCentery)
	ON_BN_CLICKED(IDC_BOTTOM, OnBottom)
	ON_BN_CLICKED(IDC_CB_CUSTOM, OnCbCustom)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_INFO, OnInfo)
	ON_BN_CLICKED(IDC_CB_WINBACK, OnCbWinback)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImgTestDlg message handlers

BOOL CImgTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	

    // ==> two lines of code:
    m_img.CreateFromStatic( GetDlgItem(IDC_ST_IMG));
    m_img.SetImg(IDB_BITMAP2);
    // <==
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CImgTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CImgTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CImgTestDlg::OnSize(UINT nType, int cx, int cy) 
{

	CDialog::OnSize(nType, cx, cy);
    if (!::IsWindow(m_hWnd)) return;

    CWnd * sc = GetDlgItem(IDC_ST_IMG);
    if (!sc || !::IsWindow(sc->m_hWnd)) return;


    static int deltaX = 0, deltaY; 
    if (deltaX == 0 && sc) {
      CRect r, cr;
      sc->GetWindowRect(&r);
      ScreenToClient(&r);
      GetClientRect(&cr);
      deltaX = -cr.right + r.Width(); // cr.right; // - r.right;
      deltaY = -cr.bottom + r.Height(); // cr.bottom - r.bottom;
    }

    sc->SetWindowPos( 0, 0,0, cx+deltaX, cy+deltaY, SWP_NOMOVE);
}

void CImgTestDlg::On11() 
{
  m_img.SetBltMode(m_img.bltNormal);	
}

void CImgTestDlg::OnStretch() 
{
  m_img.SetBltMode(m_img.bltStretch);	
}

void CImgTestDlg::OnStretchxy() 
{
  m_img.SetBltMode(m_img.bltFitXY);	
}

void CImgTestDlg::OnStretchsm() 
{
  m_img.SetBltMode(m_img.bltFitSm);	
}



void CImgTestDlg::OnTile() 
{
  m_img.SetBltMode(m_img.bltTile);	
}



void CImgTestDlg::OnRbLeft() 
{
    m_img.SetAlign(m_img.bltLeft, 0);
}

void CImgTestDlg::OnCenterx() 
{
    m_img.SetAlign(m_img.bltCenter, 0);
}

void CImgTestDlg::OnRight() 
{
    m_img.SetAlign(m_img.bltRight, 0);
}

void CImgTestDlg::OnTop() 
{
    m_img.SetAlign(0, m_img.bltTop);
}

void CImgTestDlg::OnCentery() 
{
    m_img.SetAlign(0, m_img.bltCenter);
}

void CImgTestDlg::OnBottom() 
{
    m_img.SetAlign(0, m_img.bltBottom);
}



// ===== Custom Demo ======

struct CustomEntry 
{
  int blt, alignX, alignY;
  double zoomX, zoomY;
  int    originX, originY;
  double sourceSel;
}
#define w CWndImage
customEntries[] =
{
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0 },

 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.9 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.8 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.7 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.6 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.5 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.4 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.3 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.2 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.1 },
 { w::bltCustom,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0 },
 { w::bltCustom,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.2 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.4 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.6 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 0.8 },
 { w::bltNormal,   w::bltCenter, CWndImage::bltCenter, 0,0,0,0, 1 },

 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.1,1.1,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.2,1.2,0,0,0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.3,1.3,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.4,1.4,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.5,1.5,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.6,1.6,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.7,1.7,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.8,1.8,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 1.9,1.9,0,0, 0 },
 { w::bltCustom,     w::bltCenter, CWndImage::bltCenter, 2,  2,0,0, 0 },

 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 2,  2,   5, 10, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 1.6, 1.6, 10, 20, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 1.3, 1.3, 15, 30, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 1, 1, 20, 40, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.6, 0.6, 25, 50, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.3,  0.3,    30, 60, 0 },

 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.26,  0.36,    30, 60, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.23,  0.43,    25, 50, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.20,  0.50,    20, 40, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.16,  0.56,    15, 30, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.13,  0.63,    10, 20, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.10,  0.70,    00, 10, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.06,  0.76,    00, 00, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.03,  0.83,    00, 00, 0 },
 { w::bltCustom,     w::bltCustom, CWndImage::bltCustom, 0.00,  0.90,    00, 00, 0 },
};

const int customCount = sizeof(customEntries)/sizeof(customEntries[0]);


void CImgTestDlg::OnCbCustom() 
{
  if (IsDlgButtonChecked(IDC_CB_CUSTOM)) {
    SetTimer(1, 0, 0);
  }
}

void CImgTestDlg::OnTimer(UINT nIDEvent) 
{
  static int step = 0;
  if (IsDlgButtonChecked(IDC_CB_CUSTOM)) {
    ++step;
    if (step>=customCount) step = 0;
    CustomEntry & ce = customEntries[step];

    if(ce.sourceSel!=0) 
    {
      int xsize = m_img.GetImgSizeX();
      int ysize = m_img.GetImgSizeY();

      m_img.SetSourceRect( CRect((int) (xsize * (0.5-ce.sourceSel/2)),
                                 (int) (ysize * (0.5-ce.sourceSel/2)),
                                 (int) (xsize * (0.5+ce.sourceSel/2)),
                                 (int) (ysize * (0.5+ce.sourceSel/2))));
    }
    else
      m_img.SetSourceRect();

    m_img.SetBltMode(ce.blt);
    if (ce.blt == m_img.bltCustom) {
      m_img.SetZoom(ce.zoomX, ce.zoomY);
    }
    m_img.SetAlign(ce.alignX, ce.alignY);
    if (ce.alignX == m_img.bltCustom)  m_img.SetOriginX(ce.originX);
    if (ce.alignY == m_img.bltCustom)  m_img.SetOriginY(ce.originY);
    SetTimer(1, 100, 0);
  }
  CDialog::OnTimer(nIDEvent);
}


void CImgTestDlg::OnInfo() 
{
  CDialog dlg(IDD_ABOUT);
  dlg.DoModal();
}

void CImgTestDlg::OnCbWinback() 
{
    m_img.SetBackgroundBrush( IsDlgButtonChecked(IDC_CB_WINBACK) ? 
                COLOR_WINDOW : COLOR_3DFACE);
}
