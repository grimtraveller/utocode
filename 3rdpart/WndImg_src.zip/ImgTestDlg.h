// ImgTestDlg.h : header file
//

#if !defined(AFX_IMGTESTDLG_H__2CC8A8E4_F359_4438_AC05_AA85588AFF1C__INCLUDED_)
#define AFX_IMGTESTDLG_H__2CC8A8E4_F359_4438_AC05_AA85588AFF1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "wndimage.h"

/////////////////////////////////////////////////////////////////////////////
// CImgTestDlg dialog

class CImgTestDlg : public CDialog
{
// Construction
public:

    CWndImage       m_img;


	CImgTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CImgTestDlg)
	enum { IDD = IDD_IMGTEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImgTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CImgTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void On11();
	afx_msg void OnStretch();
	afx_msg void OnStretchxy();
	afx_msg void OnStretchsm();
	afx_msg void OnTile();
	afx_msg void OnRbLeft();
	afx_msg void OnCenterx();
	afx_msg void OnRight();
	afx_msg void OnTop();
	afx_msg void OnCentery();
	afx_msg void OnBottom();
	afx_msg void OnCbCustom();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnInfo();
	afx_msg void OnCbWinback();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMGTESTDLG_H__2CC8A8E4_F359_4438_AC05_AA85588AFF1C__INCLUDED_)
