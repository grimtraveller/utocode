//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ImgTest.rc
//
#define IDD_IMGTEST_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDD_ABOUT                       131
#define IDC_ST_IMG                      1002
#define IDC_DD_IMG                      1004
#define IDC_CB_BROWSE                   1005
#define IDC_TOP                         1006
#define IDC_CENTERY                     1007
#define IDC_BOTTOM                      1008
#define IDC_RB_LEFT                     1009
#define IDC_RIGHT                       1010
#define IDC_CENTERX                     1011
#define IDC_1_1                         1012
#define IDC_STRETCH                     1014
#define IDC_STRETCHXY                   1015
#define IDC_STRETCHSM                   1016
#define IDC_TILE                        1017
#define IDC_CB_CUSTOM                   1018
#define IDC_INFO                        1019
#define IDC_CB_WINBACK                  1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
