; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CToolTipDlg
LastTemplate=CComboBox
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ToolTip.h"

ClassCount=4
Class1=CToolTipApp
Class2=CToolTipDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_TOOLTIP_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Class4=CTTComboBox
Resource5=IDD_TOOLTIP_DIALOG (English (U.S.))

[CLS:CToolTipApp]
Type=0
HeaderFile=ToolTip.h
ImplementationFile=ToolTip.cpp
Filter=N

[CLS:CToolTipDlg]
Type=0
HeaderFile=ToolTipDlg.h
ImplementationFile=ToolTipDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_COMBO5

[CLS:CAboutDlg]
Type=0
HeaderFile=ToolTipDlg.h
ImplementationFile=ToolTipDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_TOOLTIP_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CToolTipDlg

[DLG:IDD_TOOLTIP_DIALOG (English (U.S.))]
Type=1
Class=CToolTipDlg
ControlCount=9
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_COMBO1,combobox,1344340227
Control4=IDC_EDIT1,edit,1352728580
Control5=IDC_COMBO2,combobox,1344340226
Control6=IDC_COMBO3,combobox,1344340225
Control7=IDC_COMBO4,combobox,1344340227
Control8=IDC_COMBO6,combobox,1344340499
Control9=IDC_COMBO5,combobox,1344340499

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=6
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352

[CLS:CTTComboBox]
Type=0
HeaderFile=TTComboBox.h
ImplementationFile=TTComboBox.cpp
BaseClass=CComboBox
Filter=W
VirtualFilter=cWC
LastObject=CTTComboBox

