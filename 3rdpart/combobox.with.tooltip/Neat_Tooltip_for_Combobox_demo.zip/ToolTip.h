// ToolTip.h : main header file for the TOOLTIP application
//

#if !defined(AFX_TOOLTIP_H__C2F35BB5_BFB3_453B_A74B_F0FBA3689805__INCLUDED_)
#define AFX_TOOLTIP_H__C2F35BB5_BFB3_453B_A74B_F0FBA3689805__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CToolTipApp:
// See ToolTip.cpp for the implementation of this class
//

class CToolTipApp : public CWinApp
{
public:
	CToolTipApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolTipApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CToolTipApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOOLTIP_H__C2F35BB5_BFB3_453B_A74B_F0FBA3689805__INCLUDED_)
