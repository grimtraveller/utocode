//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ToolTip.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TOOLTIP_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_COMBO1                      1000
#define IDC_COMBO2                      1001
#define IDC_COMBO4                      1002
#define IDC_LIST1                       1003
#define IDC_EDIT1                       1004
#define IDC_CHECK1                      1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_EDIT2                       1009
#define IDC_SPIN1                       1010
#define IDC_COMBO3                      1011
#define IDC_COMBO6                      1013
#define IDC_COMBO5                      1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
