// free.h : main header file for the FREE application
//

#if !defined(AFX_FREE_H__D70F2E8D_C793_4F01_91FA_2D2F9C4DDD57__INCLUDED_)
#define AFX_FREE_H__D70F2E8D_C793_4F01_91FA_2D2F9C4DDD57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFreeApp:
// See free.cpp for the implementation of this class
//

class CFreeApp : public CWinApp
{
public:
	CFreeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFreeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFreeApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FREE_H__D70F2E8D_C793_4F01_91FA_2D2F9C4DDD57__INCLUDED_)
