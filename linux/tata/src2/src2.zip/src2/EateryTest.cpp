#include "Eatery.h"
int main()
{
	Eatery e;
	return 0;
}
