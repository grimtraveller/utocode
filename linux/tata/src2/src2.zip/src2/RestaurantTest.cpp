#include "Restaurant.h"
int main()
{
	Restaurant r;
	r.get(cin);
	return 0;
}
