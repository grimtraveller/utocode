#include "Restaurant.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    Restaurant r;
	
	//get from screen;
    r.get(cin);
	//put screen
	r.put(cout);

	return 0;
}
